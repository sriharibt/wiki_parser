from collections import defaultdict

def main():
    fields = {}
    lines = []
    lineGroups = []
    keyMode = True
    for line in open('write.txt'):
        lines += [line.strip()]
    #print lines
    i = 0
    for line in lines:
        if line == '':
            groupMode = False
            continue
        elif not groupMode:
            groupMode = True
            lineGroups += [[]]
        lineGroups[-1] += [line]
    #print(lineGroups)
    
    fields = {}
    singletons = []
    for group in lineGroups:
        if len(group) == 1:
            singletons += [group]
        else:
            fields[group[0]] = group[1:]
    for key in fields:
        print(key + '\t' + ','.join(fields[key]))

if __name__ == '__main__':
    main()
