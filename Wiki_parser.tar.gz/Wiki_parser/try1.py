#!/usr/bin/python

a=["hari","sdp"]

print a.split()
print a

