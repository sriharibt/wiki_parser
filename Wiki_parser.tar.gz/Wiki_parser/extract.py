import requests
from bs4 import BeautifulSoup
import pickle
url = "https://en.wikipedia.org/wiki/Category:Artificial_intelligence_researchers"
response = requests.get(url)
# parse html
page = str(BeautifulSoup(response.content,"lxml"))


def getURL(page):
    """

    :param page: html of web page (here: Python home page) 
    :return: urls in that page 
    """
    start_link = page.find('a href="/wiki/')
    if start_link == -1:
        return None, 0
    start_quote = page.find('"', start_link)
    end_quote = page.find('"', start_quote + 1)
    url = page[start_quote + 1: end_quote]
    return url, end_quote


def getname(pkl):
    start_link = pkl.find('<title>')
    start_quote = pkl.find('"', start_link)
    end_quote = pkl.find('"', start_quote + 1)
    name = pkl[start_quote + 1: end_quote]
    return name, end_quote
    
def getSoup(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"lxml")
    return soup

def pickleSoup(fileName, soup):
    fileobject=open(fileName,'wb')
    pickle.dump(soup,fileobject)
    fileobject.close()
    #soup.pickle()


#def main():
    urls = []
    names = []
    while True:
        url, n = getURL(page)
        page = page[n:]
        if url:
            if ':' not in url:
                urls += [url]
        else:
            break
    del urls[0]
    prefix = 'https://wikipedia.org'
    urls = [prefix + url for url in urls]
    print ('\n'.join(urls))
    
    
    
    total = len(urls)
    i = 0
    for url in urls:
        print(str(i) + ' of ' + str(total))
        i += 1
        soup = getSoup(url)
        soup=str(soup)	
        fileName = url.split('/')[4] + '.pkl'
        pickleSoup(fileName, soup)
        pkl=open(fileName,'r')
        name, n = getname(pkl)
        names += [name]
        print ('\n'.join(names))
      
    
#if __name__ == '__main__':
    #main()    


    

