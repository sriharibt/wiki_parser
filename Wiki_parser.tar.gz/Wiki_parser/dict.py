dict={'Name':'srihari','Born':'1996'}
print dict['Name']
print dict['Born']
