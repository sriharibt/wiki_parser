import requests
from bs4 import BeautifulSoup


def author():
	url="https://en.wikipedia.org/wiki/Category:Artificial_intelligence_researchers"
	source_code = requests.get(url)
	plain_text = source_code.text
	soup=BeautifulSoup(plain_text)

	for link in soup.find_all('a href="wiki/')