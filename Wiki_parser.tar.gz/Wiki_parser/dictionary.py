for key in fields:
