import re
str = 'srihari915@gmail.com'


match = re.search(r'[a-z,0-9]+@(\w)*[.]\w\w+',str)
if match:
	print 'found' + match.group()
else:
	print 'not found'