import scraperwiki
import yaml
import urllib2


url = 'http://en.wikipedia.org/w/api.php?action=query&titles=Hal_Abelson&prop=revisions&rvprop=content&format=yaml&rvsection=0&redirects'
wiki_file  = urllib2.urlopen(url)
data = wiki_file.read()
print data
data = yaml.load(data)
print data
