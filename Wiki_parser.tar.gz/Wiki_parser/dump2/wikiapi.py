import os

with open("/home/srihari/python_files/dump/names.txt", "r") as f:

        for line in f:
            line1 =line.rstrip('\n')
            fp = open("content2.txt","a")
            fp.write("https://en.wikipedia.org/w/api.php?action=query&prop=revisions&rvprop=content&format=xmlfm&titles="+line1+"\n")
            
        fp.close()    
            
            
            
            
