import os


os.system("wget -i content2")
