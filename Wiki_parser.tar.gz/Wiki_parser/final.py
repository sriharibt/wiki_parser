import urllib2
from bs4 import BeautifulSoup
url = 'https://en.wikipedia.org/wiki/Category:Artificial_intelligence_researchers'

conn = urllib2.urlopen(url)
html = conn.read()

soup = BeautifulSoup(html)
links = soup.find_all('a')

for tag in links:
    link = tag.get('href',None)
    if link is not None:
        if ':' is not in link:
            print link


