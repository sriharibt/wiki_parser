import xml.etree.ElementTree as ET
import re
fd=open('write.txt')
txt=fd.read()
root = ET.fromstring(txt)

for child in root.iter():
	att=child.attrib
	#print child.tag, att
	if('class' in att):
		if(att['class']=="infobox vcard"):
			print child.tag, child
			ibox_table=child
			for e in child.iter():
				print e.tag, e.text





