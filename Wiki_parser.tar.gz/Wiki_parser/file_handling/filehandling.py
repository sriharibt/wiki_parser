import re
from bs4 import BeautifulSoup
import urllib2
from collections import defaultdict
from lxml import html
import requests
import os.path
import csv

keylist=set()
finalDict ={}
file_list =[]
key_dict = {}
name_dict ={}
ids =0
Visited_keys = set([])

fpoint = open("text.txt",'a')


def read_file_to_list():
    with open("/home/srihari/python_files/dump/names.txt", "r") as f:

        for line in f:
            line1 =line.rstrip('\n')
            file_list.append(line1)
            
                
def extract_info_box(line1):
    fp = open("/home/srihari/python_files/dump/"+line1,"r")
    soup = BeautifulSoup(fp.read(),"lxml")
    table = soup.find('table', class_='infobox vcard')
    string = re.sub("<.*?>","",str(table))
    fx = open("write.txt",'w')
    
    fx.write(string)
    fx.close()
    parse_info_box()
        
    

def parse_info_box():
            global name_dict,ids,Visited_keys,key_dict             
            fields = {}
            lines = []
            lineGroups = []
            keyMode = True
            for line in open('write.txt'):
                lines += [line.strip()]
    #print lines
            for line in lines:
                if line == '':
        	        continue
                else:
        	        name = line
        	        break
            if name == 'None':
                return
                	
            print ("Name :" + name)
            name_dict[name]=ids
            ids = ids+1    	

            i = 0
            for line in lines:
                if line == '':
                    groupMode = False
                    
                    continue
                elif not groupMode:
                    
                    groupMode = True
                    lineGroups += [[]]
                lineGroups[-1] += [line]
    #print(lineGroups)
     
            fields = {}
            singletons = []
            for group in lineGroups:
                if len(group) == 1:
                    singletons += [group]
                else:
                    fields[group[0]] = group[1:]
                    keylist.add(group[0])
            out = open("result.txt",'a')
            fd = open("result_in_ids",'a')
            
            assign_ids(fields)
            
            
            
            for key in fields.keys():
                found = 0
                first = True
              
                if (key=='Alma mater'):
                    found =1
                    fpoint.write(name+'\t')
                    for element in fields[key]:
                        cleantxt = re.sub(r'([^\s\w,]|_)', '', str(element))
                        cleantxt = cleantxt.strip()
                        
                        fpoint.write(cleantxt+';')
                    fpoint.write('\n')        
                
                if(found==0):
                    fpoint.write(name +'\t'+'-'+'\n')
                
                
                
                
                
                
                
                for element in fields[key]:
                    '''
                    if ((key == 'Dave Barker-Plummer') or (key == 'Stephen Muggleton[1]') or(key == 'David Ackley')or(key == 'Ana Armas[citation needed]')or (key =='James Robert Slagle')or (key=='Robert Anderson,')or(key=='Matthew Beal[5]')):
                        if(first):
                            out.write(name +'\t\t\t'+'Doctoral students' + '\t\t\t' + key + '\n')
                            first = False
                        out.write(name +'\t\t\t'+ 'Doctoral students' + '\t\t\t' + str(element) + '\n')
                        
                    
                    elif(key=='Michael I. Jordan'):
                        if(first):
                            out.write(name +'\t\t\t'+'Doctoral Advisor' + '\t\t\t' + key + '\n')
                            first = False
                        out.write(name +'\t\t\t'+ 'Doctoral Advisor' + '\t\t\t' + str(element) + '\n')
                        
                    elif(key=='Automated reasoning'):
                        if(first):
                            out.write(name +'\t\t\t'+'Fields' + '\t\t\t' + key + '\n')
                            first = False
                        out.write(name +'\t\t\t'+ 'Fields' + '\t\t\t' + str(element) + '\n')    
                    
                    
                    
                    elif (key=='Yann LeCun (postdoc)'):
                        if(first):
                            out.write(name +'\t\t\t'+'Other notable students' + '\t\t\t' + key + '\n')
                            first = False
                        out.write(name +'\t\t\t'+ 'Other notable students' + '\t\t\t' + str(element) + '\n')
                                    
                    elif (key=='Artificial intelligence[4]')or (key == 'Backpropagation')or(key == 'Inductive Logic Programming')or(key=='Graphical models')or(key =='Artificial Intelligence: A Modern Approach')or(key=='Semantic Web'):
                        if(first):
                            out.write(name +'\t\t\t'+'Known for' + '\t\t\t' + key + '\n')
                            first = False
                        out.write(name +'\t\t\t'+ 'Known for' + '\t\t\t' + str(element) + '\n')
                        
                    elif (key=='Imperial College London')or(key=='University of Cambridge')or(key=='Stanford University; Massachusetts Institute of Technology;')or(key=='Bletchley Park')or(key=='College of Engineering, Pune'):
                        if(first):
                            
                                
                            out.write(name +'\t\t\t'+'Institutions' + '\t\t\t' + key + '\n')
                            first = False
                        out.write(name +'\t\t\t'+ 'Institutions' + '\t\t\t' + str(element) + '\n')
                                        
                    
                    
                        
                    elif ((key=='FRS (1998)[6]')or (key =='Engelmore Prize for Innovative Applications of Artificial Intelligence, 2003 (presented by the American Association for Artificial Intelligence)')or key=='Bronze Star Medal 1945')or(key=='Turing Award (1969)')or(key=='Roger Needham award (2005)[14]'):
                        if(first):
                            out.write(name +'\t\t\t'+'Notable awards' + '\t\t\t' + key + '\n')
                            first = False
                        out.write(name +'\t\t\t'+ 'Notable awards' + '\t\t\t' + str(element) + '\n')
                        
                            
                    
                    elif (key=='Pooyan Fazli, Jay Glicksman, William S. Havens, Alex Kean, Farzin Mokhtarian, Jan Mulder, Jane I. Mulligan, Robert Jr. St-Aubin, Pooja Viswanathan,'):
                        if(first):
                            string = key
                            mylist = string.split(',')
                            for itera in mylist:
                            
                                out.write(name +'\t\t\t'+'Doctoral students' + '\t\t\t' + str(itera)+'' + '\n')
                           
                            out.write(name +'\t\t\t'+ 'Doctoral students' + '\t\t\t' + 'Ying Zhang' + '\n')    
                    '''
                    
                    #elif (','in element):
                        #string =element
                        #mylist = string.split(',')
                        #for itera in mylist:
                            #out.write(name +'\t\t\t'+key + '\t\t\t' + str(itera) + '\n')
                    
                    
                    if (';'in element):
                        string =element
                        mylist = string.split(';')
                        for itera in mylist:
                            out.write(name +'\t\t\t'+key + '\t\t\t' + str(itera) + '\n')        
                     
                            
                    
                    
                    
                    
                    
                    out.write(name +'\t\t\t'+ key + '\t\t\t' + str(element) + '\n')
                    
                
               
                
                
                
                fd.write(str(name_dict.get(name))+'\t\t\t'+str(key_dict.get(key))+'\t\t\t' +get_id(fields,key) + '\n')
            
            
                
                
                
                                
           
            out.close()
            fd.close()
            
                    


def author_id():
    global name_dict
    with open("id_name",'w') as f:
        for key, value in sorted(name_dict.iteritems(), key=lambda (k,v): (v,k)):
            f.write( "%s \n" % (key))


def assign_ids(fields):
    global finalDict ,ids,Visted_keys
    
    #Declaration of finalDict (to avoid key error)     
    for key in fields:
        if key not in  Visited_keys:
            finalDict[str(key)]={}
            Visited_keys.add(key)
    # Assigning ids for keys   
    for key in fields.keys():
        if key not in key_dict:
            key_dict[key]=ids
            ids =ids+1        
            
    for key in fields:
        temp={}
        
        index=0
         
        for x in fields[key]:
            
            cleantxt = re.sub(r'([^\s\w,]|_)', '', str(x))
            cleantxt = cleantxt.strip()                    
            index = index + 1
            if cleantxt not in finalDict[str(key)]:
                
                temp[cleantxt]=ids
                ids =ids+1
                
        finalDict[str(key)].update(temp)
            
 
    
def write_fields_key_id():
    global finalDict
    save_path = 'key_id/'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    for key in finalDict:
        filename = key+".txt"
        complete_name = os.path.join(save_path,filename)
        f = open(complete_name, "w")
             
        for k , val in sorted(finalDict[str(key)].items()):
            f.write('%s\t%s\n' % (k,val))

def write_id_fields_key():
    global finalDict
    save_path = 'id_key/'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    
    for key in finalDict:
        filename = key +".txt"
        complete_name = os.path.join(save_path,filename)
        f = open(complete_name, "w")
        
        for key, value in sorted(finalDict[str(key)].iteritems(), key=lambda (k,v): (v,k)):
            f.write( "%s: %s \n" % (value, key))          

def id_for_keys():
    global ids
    
    f= open('keys.txt', 'w')
    for key ,value in sorted(key_dict.iteritems(), key =lambda (k,v): (v,k)):
        f.write('%s\t%s\n' % (value,key))     

def final_output():
    pass    


def get_id(fields,key):
    x = ''
    
    for ele in fields[key]:
        search_ele = re.sub(r'([^\s\w,]|_)', '', str(ele))
        search_ele = search_ele.strip()
        try:    
            x = str(finalDict[key][search_ele])+','+x
        except:
            print 'error '+ (search_ele)
    return x
           
    
                           
def main():
    global finalDict
    read_file_to_list()
    for line in file_list:
        extract_info_box(line)
    author_id()
    write_fields_key_id()
    write_id_fields_key()
    id_for_keys()
    
    
    

    
if __name__ == '__main__':
    main()
