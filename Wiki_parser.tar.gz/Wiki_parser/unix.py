
import os 

def main():
    os.system("sh shellscript.sh")


if __name__=="__main__":
    main()

