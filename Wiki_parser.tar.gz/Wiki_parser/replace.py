import re
with open('hals.html', 'r') as myfile:
    data=myfile.read().replace('\n', '')
    result =re.sub("<.*?>","",data)

print result
