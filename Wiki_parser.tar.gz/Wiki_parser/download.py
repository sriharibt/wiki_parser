import urllib
import re
import sys
import os

os.system("wget -i content")
