import re
from bs4 import BeautifulSoup
import urllib2
from collections import defaultdict
from lxml import html
import requests
import re



def getURL(page):
	start_link = page.find('a href="/wiki/')
	if start_link == -1:
		return None , 0
	start_quote = page.find('"', start_link)
	end_quote = page.find('"', start_quote + 1)
	url = page[start_quote + 1: end_quote]
	return url, end_quote


def main():
    url = "https://en.wikipedia.org/wiki/Category:Artificial_intelligence_researchers"
    response = requests.get(url)
    page = str(BeautifulSoup(response.content,"lxml"))

    urls =[]
    while True:
        url, n = getURL(page)
        page = page[n:]
        if url:
            if ':' not in url:
            	urls += [url]
        else:
            break
    del urls[0]
    prefix = 'https://wikipedia.org'
    urls = [prefix + url for url in urls]
           
    for url in urls:
        site= url
        hdr = {'User-Agent': 'Mozilla/5.0'}
        req = urllib2.Request(site,headers=hdr)
        page = urllib2.urlopen(req)
        soup = BeautifulSoup(page.read(),"lxml")
        table = soup.find('table', class_='infobox vcard')
        

        string = re.sub("<.*?>","",str(table))
        f = open("write.txt",'w')

        f.write(string)

    
        f.close()
        fields = {}
        lines = []
        lineGroups = []
        keyMode = True
        for line in open('write.txt'):
            lines += [line.strip()]
    #print lines
        for line in lines:
            if line == '':
        	    continue
            else:
        	    name = line
        	    break
        if name == 'None':
            continue	
        print ("Name :" + name + '\tUrl:' + url)    	

        i = 0
        for line in lines:
            if line == '':
                groupMode = False
                continue
            elif not groupMode:
                groupMode = True
                lineGroups += [[]]
            lineGroups[-1] += [line]
    #print(lineGroups)
     
        fields = {}
        singletons = []
        for group in lineGroups:
            if len(group) == 1:
                singletons += [group]
            else:
                fields[group[0]] = group[1:]
        out = open("result.txt",'a')
        out.write(name + '\n')        
        for key in fields:
    	
            out.write( key + '\t' + ','.join(fields[key]) + '\n')

        out.close()    







if __name__ == '__main__':
    main()        
 









