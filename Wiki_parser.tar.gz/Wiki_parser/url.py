import requests
from bs4 import BeautifulSoup
import pickle
url = "https://en.wikipedia.org/wiki/Category:Artificial_intelligence_researchers"
response = requests.get(url)
# parse lxml
page = str(BeautifulSoup(response.content,"lxml"))
    
def getURL(page):  
    """

    :param page: html of web page (here: Python home page) 
    :return: urls in that page 
    """
    start_link = page.find('a href="/wiki/')
    if start_link == -1:
        return None, 0
    start_quote = page.find('"', start_link)
    end_quote = page.find('"', start_quote + 1)
    url = page[start_quote + 1: end_quote]
    return url, end_quote


def getname(url_sub):
    response = requests.get(url)
    page_sub =str(BeautifulSoup(response.content,"lxml"))
    start_link = page_sub.find('<title>')
    if start_link == -1:
    	return None, 0 
    start_quote = page_sub.find('"', start_link)
    end_quote = page_sub.find('"', start_quote + 1)
    name = page_sub[start_quote + 1: end_quote]
    return name, end_quote



def getname()







def getdob(url_sub):
    response = requests.get(url)
    page_sub =str(BeautifulSoup(response.content,"lxml"))

    start_link = page_sub.find('')
    if start_link == -1:
    	return None, 0 
    start_quote = page_sub.find('"', start_link)
    end_quote = page_sub.find('"', start_quote + 1)
    name = page_sub[start_quote + 1: end_quote]
    return dob, end_quote

urls = []
names = []
born = []
i = 0
while True:
	url, n = getURL(page)
	page = page[n:]
	if url:
		if ':' not in url:
			urls += [url]
        else:
        	break
del urls[0]
prefix = 'https://wikipedia.org'
urls = [prefix + url for url in urls]
print ('\n'.join(urls))
for i in range(0,n):
	name, n = getname(urls[i])
	names += [name]

    #dob, n = getdob(urls[i])
    #born += [born]
print (names)
#table(names,born,n)