from lxml import html
import requests
import re
from bs4 import BeautifulSoup
url='https://en.wikipedia.org/wiki/Ayanna_Howard'
page = requests.get('https://en.wikipedia.org/wiki/Ayanna_Howard')
response = requests.get(url)
soup = BeautifulSoup(response.content,"lxml")
tree = html.fromstring(page.content)
name = tree.xpath('//h1[@class="firstHeading"]/text()')
born = tree.xpath('//span[@class="bday"]/text()')
fields = [a.findAll(text=True) for a in soup.findAll('td', {'class': 'category'})]



weightMatrix = []
'''for k in range(motifWidth):'''
weightMatrix[0] = {'Name':name,'Born':born,'Fields':fields}


	

print weightMatrix[0]
#print inst
